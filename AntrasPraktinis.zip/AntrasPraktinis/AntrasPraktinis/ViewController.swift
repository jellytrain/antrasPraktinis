//
//  ViewController.swift
//  AntrasPraktinis
//
//  Created by Vilius Zamara on 2020-09-23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstNameField: UITextField!
    @IBOutlet weak var lastNameField: UITextField!
    @IBOutlet weak var birthDateTxt: UITextField!
    
    
    @IBOutlet weak var erorMessage: UILabel!
    
    
    let datePicker = UIDatePicker()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        firstNameField.delegate = self
        lastNameField.delegate = self
        
        createDatePicker()
        // Do any additional setup after loading the view.
    }
    
    func createDatePicker(){
        
        let calendar = Calendar(identifier: .gregorian)
        
        let curentDate = Date()
        
        var components = DateComponents()
        
        components.calendar = calendar
        

        datePicker.maximumDate = Calendar.current.date(byAdding: .year, value: 0, to: curentDate)
        
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
        toolbar.setItems([doneButton], animated: true)
        
        birthDateTxt.inputAccessoryView = toolbar
        
        birthDateTxt.inputView = datePicker
        
        datePicker.datePickerMode = .date
        
        
    }
    
    @objc func donePressed(){
        
        let formatter = DateFormatter()
        
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        
        birthDateTxt.text = formatter.string(from: datePicker.date)
        self.view.endEditing(true)
    }


    @IBAction func tapped(_ sender: Any) {
        
        erorMessage.isHidden = true
        
        guard let _ = firstNameField.text, firstNameField.text?.count != 0 else {
            erorMessage.isHidden = false
            erorMessage.text = "Please enter your name"
            return
        }
        guard let _ = lastNameField.text, lastNameField.text?.count != 0 else {
            erorMessage.isHidden = false
            erorMessage.text = "Please enter your Last Name"
            return
        }
        
        
    }
    
}

extension ViewController : UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

